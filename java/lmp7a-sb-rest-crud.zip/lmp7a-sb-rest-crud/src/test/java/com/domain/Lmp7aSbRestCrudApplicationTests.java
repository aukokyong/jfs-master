package com.domain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lmp7aSbRestCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
